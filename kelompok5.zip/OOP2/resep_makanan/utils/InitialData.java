package resep_makanan.utils;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import resep_makanan.models.*;

public class InitialData {
    private ArrayList<Bahan> dataArtis = new ArrayList<>();
    private ArrayList<Makanan> dataMakanan = new ArrayList<>();
    private ArrayList<User> dataUser = new ArrayList<>();
    private ArrayList<ResepMakanan> dataResepMakanan = new ArrayList<>();
    private DateTimeFormatter pattern = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public ArrayList<User> initApoteker() {
        User user = new User();
        user.setUsername("admin");
        user.setEmail("admin@gmail.com");
        user.setPassword("admin");
        dataUser.add(user);

        user = new User();
        user.setUsername("tukiman");
        user.setEmail("tukiman@gmail.com");
        user.setPassword("tukiman");
        dataUser.add(user);

        return dataUser;
    }

    public ArrayList<ResepMakanan> initCustomer() {
        ResepMakanan resepMakanan = new ResepMakanan("Nasi Goreng", "Resep Nasi Goreng Cak Ropik", "\r\n" + //
                "\t - 1 siung bawang putih, cincang\r\n" + //
                "\t - 2 buah cabai rawit, cincang\r\n" + //
                "\t - Garam dan gula secukupnya\r\n" + //
                "\t - 1 piring nasi putih\r\n" + //
                "\t - 4 siung bawang merah, cincang\r\n" + //
                "\t - 1 batang daun seledri, cincang\r\n" + //
                "\t - 1 butir telur, kocok lepas\r\n" + //
                "\t - 1 genggam kol, potong-potong dan goreng\r\n" + //
                "\t - 1 sdm saus tiram");
        dataResepMakanan.add(resepMakanan);

        resepMakanan = new ResepMakanan("Mie Ayam", "Resep Mie Ayam Khas Lamongan", "\r\n" + //
                "\t - Mi basah atau mie telor 500 g\r\n" + //
                "\t - Daging ayam 300 g\r\n" + //
                "\t - Minyak ayam 500 ml\r\n" + //
                "\t - Bawang putih 4 siung\r\n" + //
                "\t - Bawang merah 4 buah\r\n" + //
                "\t - Ketumbar 1 sdt\r\n" + //
                "\t - Kunyit seruas jari\r\n" + //
                "\t - Kemiri 4 butir\r\n" + //
                "\t -Jahe 1 ruas\r\n" + //
                "\t - Air rebusan daging ayam 2 L\r\n" + //
                "\t - Lada bubuk 1 sdt\r\n" + //
                "\t - Garam 1 sdt\r\n" + //
                "\t - Tulang ayam secukupnya");
        dataResepMakanan.add(resepMakanan);

        resepMakanan = new ResepMakanan("Ayam Goreng", "Resep Ayam Goreng Khas Bondowoso", " \r\n" + //
                "\t - 4 siung bawang putih\r\n" + //
                "\t - 1 ruas jahe\r\n" + //
                "\t - 1 ruas kunyit\r\n" + //
                "\t - ½ sdt ketumbar\r\n" + //
                "\t - kaldu ayam bubuk secukupnya \r\n" + //
                "\t - Garam secukupnya\r\n" + //
                "\t - 4 lbr daun salam\r\n" + //
                "\t - air secukupnya\r\n" + //
                "\t - kelapa parut secukupnya");
        dataResepMakanan.add(resepMakanan);

        return dataResepMakanan;
    }

    public ArrayList<Makanan> initKategori() {
        Makanan makanan = new Makanan("Nasi Goreng");
        dataMakanan.add(makanan);

        makanan = new Makanan("Ayam Goreng");
        dataMakanan.add(makanan);

        makanan = new Makanan("Mie Ayam");
        dataMakanan.add(makanan);

        return dataMakanan;
    }

    public ArrayList<Bahan> initBahan() {
        Bahan bahan = new Bahan("Cabai");
        bahan.setJumlah("10 kg");
        bahan.setResepId("RS001");
        dataArtis.add(bahan);

        bahan = new Bahan("Bawang Merah");
        bahan.setJumlah("5 kg");
        bahan.setResepId("RS002");
        dataArtis.add(bahan);

        bahan = new Bahan("Bawang Putih");
        bahan.setJumlah("4 kg");
        bahan.setResepId("RS003");
        dataArtis.add(bahan);

        return dataArtis;
    }
}
