package resep_makanan.models;

import java.util.UUID;

public class User {
    private String id, username, email, password;
    private boolean isLogin;

    public User() {};
    public User(String username, String email, String password) {
        this.id = UUID.randomUUID().toString();
        this.username = username;
        this.email = email;
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public void setUsername(String nama) {
        this.username = nama;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean login(String uName, String pWord) {
        if(this.username.equals(uName) && this.password.equals(pWord)){
            this.isLogin = true;
            return true;
        } else {
            this.isLogin = false;
            return false;
        }
    }
}