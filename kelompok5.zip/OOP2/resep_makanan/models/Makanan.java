package resep_makanan.models;

import java.util.UUID;

public class Makanan {
    private String idMakanan;
    private String nama;
    private String resepId;

    public Makanan(String nama) {
        this.idMakanan = UUID.randomUUID().toString();
        this.nama = nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setIdMakanan(String idMakanan) {
        this.idMakanan = idMakanan;
    }

    public void setResepId(String resepId) {
        this.resepId = resepId;
    }

    public String getIdMakanan() {
        return idMakanan;
    }

    public String getNama() {
        return nama;
    }

    public String getResepId() {
        return resepId;
    }
}
