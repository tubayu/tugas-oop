package resep_makanan.models;

import java.time.LocalDateTime;
import java.util.UUID;

public class ResepFavorit {
    private String idResepFavorit;

    private String userId;
    private String resepId;
    private LocalDateTime tanggalDitambahkan;

    public ResepFavorit() {};
    public ResepFavorit(String userId, String resepId) {
        this.idResepFavorit = UUID.randomUUID().toString();
        this.userId = userId;
        this.resepId = resepId;
        this.tanggalDitambahkan = LocalDateTime.now();
    }

    public String getUserId() {
        return userId;
    }

    public String getResepId() {
        return resepId;
    }

    public LocalDateTime getTanggalDitambahkan() {
        return tanggalDitambahkan;
    }

    public String getIdResepFavorit() {
        return idResepFavorit;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setResepId(String resepId) {
        this.resepId = resepId;
    }
}
