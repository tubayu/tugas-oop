package resep_makanan.models;

import java.util.UUID;

public class Bahan {
    private String idBahan;
    private String nama;
    private String resepId;
    private String jumlah;

    public Bahan() {};
    public Bahan(String nama) {
        this.idBahan = UUID.randomUUID().toString();
        this.nama = nama;
    }

    public String getIdBahan() {
        return idBahan;
    }

    public String getNama() {
        return nama;
    }

    public String getResepId() {
        return resepId;
    }

    public String getJumlah() {
        return jumlah;
    }


    public void setIdBahan(String idBahan) {
        this.idBahan = idBahan;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setResepId(String resepId) {
        this.resepId = resepId;
    }

    public void setJumlah(String jumlah) {
        this.jumlah = jumlah;
    }
}
