package resep_makanan.models;

import java.util.UUID;

public class ResepMakanan {
    private String idResepMakanan;
    private String namaMakanan;
    private String userId;
    private String Deskripsi;

    public ResepMakanan() {};
    public ResepMakanan(String namaMakanan, String userId, String Deskripsi) {
        this.idResepMakanan = UUID.randomUUID().toString();
        this.namaMakanan = namaMakanan;
        this.userId = userId;
        this.Deskripsi = Deskripsi;
    }

    public String getIdResepMakanan() {
        return idResepMakanan;
    }

    public String getNamaMakanan() {
        return namaMakanan;
    }

    public String getUserId() {
        return userId;
    }

    public String getDeskripsi() {
        return Deskripsi;
    }

    public void setNamaMakanan(String namaMakanan) {
        this.namaMakanan = namaMakanan;
    }

    public void setIdResepMakanan(String idResepMakanan) {
        this.idResepMakanan = idResepMakanan;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setDeskripsi(String deskripsi) {
        this.Deskripsi = deskripsi;
    }
}
