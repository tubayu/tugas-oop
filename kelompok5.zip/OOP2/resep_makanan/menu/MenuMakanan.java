package resep_makanan.menu;

import resep_makanan.models.Makanan;
import resep_makanan.models.Menu;
import resep_makanan.utils.ScreenHelper;

import java.util.ArrayList;
import java.util.UUID;

public class MenuMakanan extends Menu {
    private ArrayList<Makanan> data;

    public MenuMakanan(ArrayList<Makanan> data) {
        this.data = data;
    }

    public void tampilMenu() {
        int pilihan;
        do {
            ScreenHelper.clearConsole();
            System.out.println("+=============================================+");
            System.out.println("|                 DATA MAKANAN               |");
            System.out.println("+=============================================+");
            System.out.println("| 1 | Tampil Makanan                         |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 2 | Tambah Makanan                         |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 3 | Edit Makanan                           |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 4 | Hapus Makanan                          |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 0 | Kembali                                |");
            System.out.println("+=============================================+");
            System.out.print("\nSilakan masukan pilihan anda (0...4) : ");
            pilihan = input.nextInt();
            input.nextLine();
            switch (pilihan) {
                case 1:
                    tampilData();
                    break;
                case 2:
                    tambah();
                    break;
                case 3:
                    edit();
                    break;
                case 4:
                    hapus();
                    break;
                case 0:
                    System.out.println("+=============================================+");
                    System.out.println("|            KEMBALI KE MENU UTAMA            |");
                    System.out.println("+=============================================+\n");
                    break;
                default:
                    System.out.println("Pilihan yang anda input tidak tersedia, silakan ulangi kembali.");
                    input.next();
            }
        } while (pilihan != 0);
    }

    public void tampilData() {
        ScreenHelper.clearConsole();
        if (data.size() > 0) {
            System.out.println("+=============================================+");
            System.out.println("|               TAMPIL DATA MAKANAN           |");
            System.out.println("+=============================================+");
            for (Makanan tempMakanan : data) {
                System.out.println("Id Makanan         : " + tempMakanan.getIdMakanan());
                System.out.println("Nama Makanan       : " + tempMakanan.getNama());
                System.out.println("Resep ID           : " + tempMakanan.getResepId());
                System.out.println("+=============================================+");
            }
            input.nextLine();
        } else {
            System.out.println("Data Makanan kosong, silakan tambahkan data.");
            input.nextLine();
        }
    }

    public void tambah() {
        ScreenHelper.clearConsole();

        System.out.println("+=============================================+");
        System.out.println("|              TAMBAH DATA MAKANAN            |");
        System.out.println("+=============================================+");

        System.out.print("Makanan       : ");
        String makanan = input.nextLine();

        System.out.print("Resep ID      : ");
        String resepId = input.nextLine();

        Makanan tempMakanan = new Makanan(makanan);
        tempMakanan.setIdMakanan(UUID.randomUUID().toString());
        tempMakanan.setResepId(resepId);
        data.add(tempMakanan);

        System.out.println("+=============================================+");
        System.out.println("|             DATA MAKANAN TERSIMPAN         |");
        System.out.println("+=============================================+");
        input.nextLine();
    }

    public void edit() {
        int indexMakanan = pilih();
        if (indexMakanan != -1) {
            Makanan editMakanan = data.get(indexMakanan);

            System.out.println("+=============================================+");
            System.out.println("|               EDIT DATA MAKANAN             |");
            System.out.println("+=============================================+");
            System.out.print("Nama Makanan      : ");
            editMakanan.setNama(input.nextLine());

            System.out.print("Resep ID          : ");
            editMakanan.setResepId(input.nextLine());

            data.set(indexMakanan, editMakanan);
            System.out.println("+=============================================+");
            System.out.println("|             DATA MAKANAN TERSIMPAN          |");
            System.out.println("+=============================================+");
            input.nextLine();
        }
    }

    public void hapus() {
        int indexMakanan = pilih();
        if (indexMakanan != -1) {
            data.remove(indexMakanan);
            System.out.println("+=============================================+");
            System.out.println("|              DATA MAKANAN DIHAPUS          |");
            System.out.println("+=============================================+");
            input.nextLine();
        }
    }

    public int pilih() {
        ScreenHelper.clearConsole();
        int genreDipilih = -1;

        if (data.size() > 0) {
            do {
                System.out.println("+=============================================+");
                System.out.println("|                PILIH MAKANAN                 |");
                System.out.println("+=============================================+");

                for (int index = 0; index < data.size(); index++) {
                    Makanan tempMakanan = data.get(index);
                    System.out.println("Index              : " + index);
                    System.out.println("Nama Makanan       : " + tempMakanan.getNama());
                    System.out.println("Resep ID           : " + tempMakanan.getResepId());
                    System.out.println("+=============================================+");
                }

                System.out.print("Silakan pilih index Makanan : ");
                genreDipilih = input.nextInt();
                input.nextLine();

            } while (genreDipilih == -1);
        } else {
            System.out.println("Data Makanan kosong, silakan tambahkan data.");
            input.nextLine();
        }
        return genreDipilih;
    }
}
