package resep_makanan.menu;

import java.util.ArrayList;
import java.util.UUID;

import resep_makanan.models.Bahan;
import resep_makanan.models.Menu;
import resep_makanan.utils.ScreenHelper;

public class MenuBahan extends Menu {
    ArrayList<Bahan> data;

    public MenuBahan(ArrayList<Bahan> data) {
        this.data = data;
    }

    @Override
    public void tampilMenu() {
        int pilihan;
        do {
            ScreenHelper.clearConsole();
            System.out.println("+=============================================+");
            System.out.println("|                  DATA BAHAN                 |");
            System.out.println("+=============================================+");
            System.out.println("| 1 | Tampil Bahan                            |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 2 | Tambah Bahan                            |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 3 | Edit Bahan                              |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 4 | Hapus Bahan                             |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 0 | Kembali                                 |");
            System.out.println("+=============================================+");
            System.out.print("\nSilakan masukan pilihan anda (0...4) : ");
            pilihan = input.nextInt();
            input.nextLine();
            switch (pilihan) {
                case 1:
                    tampilData();
                    break;
                case 2:
                    tambah();
                    break;
                case 3:
                    edit();
                    break;
                case 4:
                    hapus();
                    break;
                case 0:
                    System.out.println("+=============================================+");
                    System.out.println("|            KEMBALI KE MENU UTAMA            |");
                    System.out.println("+=============================================+\n");
                    break;
                default:
                    System.out.println("Pilihan yang anda input tidak tersedia, silakan ulangi kembali.");
                    input.next();
            }
        } while (pilihan != 0);
    }

    @Override
    public void tampilData() {
        ScreenHelper.clearConsole();
        if (data.size() > 0) {
            System.out.println("+=============================================+");
            System.out.println("|               TAMPIL DATA BAHAN             |");
            System.out.println("+=============================================+");
            for (Bahan tempBahan : data) {
                System.out.println("Kode Bahan          : " + tempBahan.getIdBahan());
                System.out.println("Nama Bahan          : " + tempBahan.getNama());
                System.out.println("Resep ID            : " + tempBahan.getResepId());
                System.out.println("Jumlah              : " + tempBahan.getJumlah());
                System.out.println("+=============================================+");
            }
            input.nextLine();
        } else {
            System.out.println("Data Bahan kosong, silakan tambahkan data.");
            input.nextLine();
        }
    }

    @Override
    public void tambah() {
        ScreenHelper.clearConsole();
        System.out.println("+=============================================+");
        System.out.println("|               TAMBAH DATA BAHAN             |");
        System.out.println("+=============================================+");
        Bahan tempBahan = new Bahan();

        System.out.print("Nama Bahan                     : ");
        tempBahan.setNama(input.nextLine());

        System.out.print("Resep Id                       : ");
        tempBahan.setResepId(input.nextLine());

        System.out.print("Jumlah                         : ");
        tempBahan.setJumlah(input.nextLine());

        tempBahan.setIdBahan(UUID.randomUUID().toString());
        data.add(tempBahan);

        System.out.println("+=============================================+");
        System.out.println("|              DATA BAHAN TERSIMPAN           |");
        System.out.println("+=============================================+");
        input.nextLine();
    }

    @Override
    public void edit() {
        ScreenHelper.clearConsole();
        int indexBahan = pilih();
        if (indexBahan != -1) {
            Bahan editBahan = data.get(indexBahan);

            System.out.println("+=============================================+");
            System.out.println("|                EDIT DATA BAHAN              |");
            System.out.println("+=============================================+");

            System.out.print("Nama Bahan                     : ");
            editBahan.setNama(input.nextLine());

            System.out.print("Resep Id                       : ");
            editBahan.setResepId(input.nextLine());

            System.out.print("Jumlah                         : ");
            editBahan.setJumlah(input.nextLine());

            data.set(indexBahan, editBahan);
            System.out.println("+=============================================+");
            System.out.println("|              DATA BAHAN TERSIMPAN           |");
            System.out.println("+=============================================+");
            input.nextLine();
        }
    }

    public void hapus() {
        ScreenHelper.clearConsole();
        int indexBahan = pilih();
        if (indexBahan != -1) {
            data.remove(indexBahan);
            System.out.println("+=============================================+");
            System.out.println("|               DATA BAHAN DIHAPUS            |");
            System.out.println("+=============================================+");
            input.nextLine();
        }
    }

    public int pilih() {
        ScreenHelper.clearConsole();
        int resepDipilih = -1;

        if (data.size() > 0) {
            do {
                System.out.println("+=============================================+");
                System.out.println("|                PILIH BAHAN                  |");
                System.out.println("+=============================================+");

                for (int index = 0; index < data.size(); index++) {
                    Bahan tempBahan = data.get(index);
                    System.out.println("Index               : " + index);
                    System.out.println("Nama Bahan          : " + tempBahan.getNama());
                    System.out.println("Resep ID            : " + tempBahan.getResepId());
                    System.out.println("Jumlah              : " + tempBahan.getJumlah());
                    System.out.println("+=============================================+");
                }

                System.out.print("Silakan pilih index Bahan : ");
                resepDipilih = input.nextInt();
                input.nextLine();

            } while (resepDipilih == -1);
        } else {
            System.out.println("Data Bahan kosong, silakan tambahkan data.");
            input.nextLine();
        }
        return resepDipilih;
    }
}
