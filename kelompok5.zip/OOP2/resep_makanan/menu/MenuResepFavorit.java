package resep_makanan.menu;

import java.util.ArrayList;

import resep_makanan.models.*;
import resep_makanan.utils.ScreenHelper;

public class MenuResepFavorit extends Menu {
    private ArrayList<ResepFavorit> data;
    private ArrayList<ResepMakanan> dataResepMakanan;
    private MenuResepMakanan menuResepMakanan;
    private User userAktif;

    public MenuResepFavorit(ArrayList<ResepFavorit> resepFavorits, ArrayList<ResepMakanan> dataResepMakanan,
            MenuResepMakanan menuResepMakanan, User userAktif) {
        this.data = resepFavorits;
        this.menuResepMakanan = menuResepMakanan;
        this.userAktif = userAktif;
        this.dataResepMakanan = dataResepMakanan;
    }

    public void tampilMenu() {
        int pilihan;
        do {
            ScreenHelper.clearConsole();
            System.out.println("+=============================================+");
            System.out.println("|                DATA RESEP FAVORIT           |");
            System.out.println("+=============================================+");
            System.out.println("| 1 | Tampil Resep Favorit                    |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 2 | Tambah Resep Favorit                    |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 3 | Edit Resep Favorit                      |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 4 | Hapus Resep Favorit                     |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 0 | Kembali                                 |");
            System.out.println("+=============================================+");
            System.out.print("\nSilakan masukan pilihan anda (0...4) : ");
            pilihan = input.nextInt();
            input.nextLine();
            switch (pilihan) {
                case 1:
                    tampilData();
                    break;
                case 2:
                    tambah();
                    break;
                case 3:
                    edit();
                    break;
                case 4:
                    hapus();
                    break;
                case 0:
                    System.out.println("+=============================================+");
                    System.out.println("|            KEMBALI KE MENU UTAMA            |");
                    System.out.println("+=============================================+\n");
                    break;
                default:
                    System.out.println("Pilihan yang anda input tidak tersedia, silakan ulangi kembali.");
                    input.next();
            }
        } while (pilihan != 0);
    }

    @Override
    public void tampilData() {
        ScreenHelper.clearConsole();
        if (data.size() > 0) {
            System.out.println("+=============================================+");
            System.out.println("|              TAMPIL DATA RESEP FAVORIT      |");
            System.out.println("+=============================================+");
            for (ResepFavorit tempResepFavorit : data) {
                System.out.println("ID Resep Favorit                : " + tempResepFavorit.getIdResepFavorit());
                System.out.println("Nama Resep                      : " + tempResepFavorit.getUserId());
                System.out.println("Nama Makanan                    : " + tempResepFavorit.getResepId());
                System.out.println("Tanggal Ditambahkan             : " + tempResepFavorit.getTanggalDitambahkan());
                System.out.println("+=============================================+");
            }
            input.nextLine();
        } else {
            System.out.println("Data Resep Favorit kosong, silakan tambahkan data.");
            input.nextLine();
        }
    }

    @Override
    public void tambah() {
        ScreenHelper.clearConsole();
        System.out.println("+=============================================+");
        System.out.println("|             TAMBAH DATA RESEP FAVORIT       |");
        System.out.println("+=============================================+");

        System.out.print("Nama Resep         : ");
        String userId = input.nextLine();

        System.out.print("Nama Makanan       : ");
        String resepId = input.nextLine();

        ResepFavorit tempResepFavorit = new ResepFavorit();
        tempResepFavorit.setUserId(userId);
        tempResepFavorit.setResepId(resepId);
        data.add(tempResepFavorit);

        System.out.println("+=============================================+");
        System.out.println("|            DATA RESEP FAVORIT TERSIMPAN     |");
        System.out.println("+=============================================+");
        input.nextLine();
    }

    @Override
    public void hapus() {
        int indexResepFavorit = pilih();
        if (indexResepFavorit != -1) {
            data.remove(indexResepFavorit);
            System.out.println("+=============================================+");
            System.out.println("|             DATA RESEP FAVORIT DIHAPUS      |");
            System.out.println("+=============================================+");
            input.nextLine();
        }
    }

    @Override
    public void edit() {
        int indexResepFavorit = pilih();
        if (indexResepFavorit != -1) {
            ResepFavorit editResepFavorit = data.get(indexResepFavorit);

            System.out.println("+=============================================+");
            System.out.println("|               EDIT DATA RESEP FAVORIT       |");
            System.out.println("+=============================================+");

            System.out.print("Nama Resep        : ");
            String userId = input.nextLine();

            System.out.print("Nama Makanan      : ");
            String resepId = input.nextLine();

            editResepFavorit.setUserId(userId);
            editResepFavorit.setResepId(resepId);

            data.set(indexResepFavorit, editResepFavorit);
            System.out.println("+=============================================+");
            System.out.println("|             DATA RESEP FAVORIT TERSIMPAN    |");
            System.out.println("+=============================================+");
            input.nextLine();
        }
    }

    @Override
    public int pilih() {
        ScreenHelper.clearConsole();
        int watchlistDipilih = -1;

        if (data.size() > 0) {
            do {
                System.out.println("+=============================================+");
                System.out.println("|                PILIH RESEP FAVORIT              |");
                System.out.println("+=============================================+");
                for (int index = 0; index < data.size(); index++) {
                    ResepFavorit tempResepFavorit = data.get(index);
                    System.out.println("INDEX                           : " + index);
                    System.out.println("Nama Resep                      : " + tempResepFavorit.getUserId());
                    System.out.println("Nama Makanan                    : " + tempResepFavorit.getResepId());
                    System.out.println("+=============================================+");
                }

                System.out.print("Silakan pilih INDEX Resep Favorit : ");
                watchlistDipilih = input.nextInt();
                input.nextLine();
            } while (watchlistDipilih == -1);
        } else {
            System.out.println("Data Resep Favorit kosong, silakan tambahkan data.");
            input.nextLine();
        }
        return watchlistDipilih;
    }
}
