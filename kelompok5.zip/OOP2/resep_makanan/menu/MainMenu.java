package resep_makanan.menu;

import java.util.ArrayList;
import java.util.Scanner;
import resep_makanan.models.*;
import resep_makanan.utils.InitialData;
import resep_makanan.utils.ScreenHelper;

public class MainMenu {
    private InitialData masterData = new InitialData();
    private ArrayList<Bahan> dataBahan = masterData.initBahan();
    private ArrayList<Makanan> dataMakanan = masterData.initKategori();
    private ArrayList<ResepMakanan> dataResepMakanan = masterData.initCustomer();
    private ArrayList<ResepFavorit> dataResepFavorit = new ArrayList<>();
    private Scanner input = new Scanner(System.in);

    private MenuBahan menuBahan;
    private MenuUser menuUser;
    private MenuResepMakanan menuResepMakanan;
    private MenuMakanan menuMakanan;
    private MenuResepFavorit menuResepFavorit;
    private User userAktif;


    public MainMenu(ArrayList<User> dataUser, User userAktif) {
        this.userAktif = userAktif;
        this.menuBahan = new MenuBahan(dataBahan);
        this.menuMakanan = new MenuMakanan(dataMakanan);
        this.menuUser = new MenuUser(dataUser);
        this.menuResepMakanan = new MenuResepMakanan(dataResepMakanan);
        this.menuResepFavorit = new MenuResepFavorit(dataResepFavorit, dataResepMakanan, menuResepMakanan, userAktif);
    }

    public void tampilMenu() {
        int pilihan;
        do {
            ScreenHelper.clearConsole();
            System.out.println("+=============================================+");
            System.out.println("|                  MAIN MENU                  |");
            System.out.println("+=============================================+");
            System.out.println("| 1 | Data Bahan                              |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 2 | Data Resep Makanan                      |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 3 | Data Makanan                            |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 4 | Resep Favorit                           |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 0 | Logout                                  |");
            System.out.println("+=============================================+");
            System.out.print("\nSilakan masukan pilihan anda (0...4) : ");
            pilihan = input.nextInt();
            input.nextLine();
            switch (pilihan) {
                case 1:
                    menuBahan.tampilMenu();
                    break;
                case 2:
                    menuResepMakanan.tampilMenu();
                    break;
                case 3:
                    menuMakanan.tampilMenu();
                    break;
                case 4:
                    menuResepFavorit.tampilMenu();
                    break;
                case 0:
                    ScreenHelper.clearConsole();
                    System.out.println("+=============================================+");
                    System.out.println("|             KELUAR DARI PROGRAM             |");
                    System.out.println("+=============================================+\n");
                    break;
                default:
                    System.out.println("Pilihan yang anda input tidak tersedia, silakan ulangi kembali.");
                    input.next();
            }
        } while (pilihan != 0);
    }
}
