package resep_makanan.menu;

import java.util.ArrayList;
import java.util.UUID;

import resep_makanan.models.ResepMakanan;
import resep_makanan.models.Menu;
import resep_makanan.utils.ScreenHelper;

public class MenuResepMakanan extends Menu {
    private ArrayList<ResepMakanan> data;

    public MenuResepMakanan(ArrayList<ResepMakanan> data) {
        this.data = data;
    }

    public void tampilMenu() {
        int pilihan;
        do {
            ScreenHelper.clearConsole();
            System.out.println("+=============================================+");
            System.out.println("|                 DATA RESEP MAKANAN          |");
            System.out.println("+=============================================+");
            System.out.println("| 1 | Tampil Resep Makanan                    |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 2 | Tambah Resep Makanan                    |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 3 | Edit Resep Makanan                      |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 4 | Hapus Resep Makanan                     |");
            System.out.println("+---+-----------------------------------------+");
            System.out.println("| 0 | Kembali                                 |");
            System.out.println("+=============================================+");
            System.out.print("\nSilakan masukan pilihan anda (0...4) : ");
            pilihan = input.nextInt();
            input.nextLine();
            switch (pilihan) {
                case 1:
                    tampilData();
                    break;
                case 2:
                    tambah();
                    break;
                case 3:
                    edit();
                    break;
                case 4:
                    hapus();
                    break;
                case 0:
                    System.out.println("+=============================================+");
                    System.out.println("|            KEMBALI KE MENU UTAMA            |");
                    System.out.println("+=============================================+\n");
                    break;
                default:
                    System.out.println("Pilihan yang anda input tidak tersedia, silakan ulangi kembali.");
                    input.next();
            }
        } while (pilihan != 0);
    }

    public void tampilData() {
        ScreenHelper.clearConsole();
        if (data.size() > 0) {
            System.out.println("+=============================================+");
            System.out.println("|              TAMPIL DATA RESEP MAKANAN      |");
            System.out.println("+=============================================+");
            for (ResepMakanan tempResepMakanan : data) {
                System.out.println("Id Resep Makanan     : " + tempResepMakanan.getIdResepMakanan());
                System.out.println("Nama                 : " + tempResepMakanan.getNamaMakanan());
                System.out.println("Deskripsi            : " + tempResepMakanan.getDeskripsi());
                System.out.println("Nama Resep           : " + tempResepMakanan.getUserId());
                System.out.println("+=============================================+");
            }
            input.nextLine();
        } else {
            System.out.println("Data Resep Makanan kosong, silakan tambahkan data.");
            input.nextLine();
        }
    }

    public void tambah() {
        ScreenHelper.clearConsole();

        System.out.println("+=============================================+");
        System.out.println("|             TAMBAH DATA RESEP MAKANAN       |");
        System.out.println("+=============================================+");

        System.out.print("Nama           : ");
        String nama = input.nextLine();

        System.out.print("Deskripsi      : ");
        String deskripsi = input.nextLine();

        System.out.print("Nama Resep     : ");
        String userId = input.nextLine();

        input.nextLine();
        ResepMakanan tempResepMakanan = new ResepMakanan();
        tempResepMakanan.setNamaMakanan(nama);
        tempResepMakanan.setUserId(deskripsi);
        tempResepMakanan.setDeskripsi(userId);

        tempResepMakanan.setIdResepMakanan(UUID.randomUUID().toString());
        data.add(tempResepMakanan);

        System.out.println("+=============================================+");
        System.out.println("|         DATA RESEP MAKANAN TERSIMPAN        |");
        System.out.println("+=============================================+");
        input.nextLine();
    }

    public void edit() {
        int indexResepMakanan = pilih();
        if (indexResepMakanan != -1) {
            ResepMakanan editResepMakanan = data.get(indexResepMakanan);

            System.out.println("+=============================================+");
            System.out.println("|              EDIT DATA RESEP MAKANAN        |");
            System.out.println("+=============================================+");

            System.out.print("Nama           : ");
            String nama = input.nextLine();

            System.out.print("Deskripsi      : ");
            String deskripsi = input.nextLine();

            System.out.print("Nama Resep     : ");
            String userId = input.nextLine();

            editResepMakanan.setNamaMakanan(nama);
            editResepMakanan.setUserId(deskripsi);
            editResepMakanan.setDeskripsi(userId);

            data.set(indexResepMakanan, editResepMakanan);
            System.out.println("+=============================================+");
            System.out.println("|        DATA RESEP MAKANAN TERSIMPAN         |");
            System.out.println("+=============================================+");
            input.nextLine();
        }
    }

    public void hapus() {
        int indexResepMakanan = pilih();
        if (indexResepMakanan != -1) {
            data.remove(indexResepMakanan);
            System.out.println("+=============================================+");
            System.out.println("|             DATA RESEP MAKANAN DIHAPUS      |");
            System.out.println("+=============================================+");
            input.nextLine();
        }
    }

    public int pilih() {
        ScreenHelper.clearConsole();
        int resepMakananDipilih = -1;

        if (data.size() > 0) {
            do {
                System.out.println("+=============================================+");
                System.out.println("|                PILIH RESEP MAKANAN          |");
                System.out.println("+=============================================+");

                for (int index = 0; index < data.size(); index++) {
                    ResepMakanan tempResepMakanan = data.get(index);
                    System.out.println("Index       : " + index);
                    System.out.println("Nama        : " + tempResepMakanan.getNamaMakanan());
                    System.out.println("Deskripsi   : " + tempResepMakanan.getDeskripsi());
                    System.out.println("Nama Resep  : " + tempResepMakanan.getUserId());
                    System.out.println("+=============================================+");
                }

                System.out.print("Silakan pilih index Resep Makanan : ");
                resepMakananDipilih = input.nextInt();
                input.nextLine();

            } while (resepMakananDipilih == -1);
        } else {
            System.out.println("Data Resep Makanan kosong, silakan tambahkan data.");
            input.nextLine();
        }
        return resepMakananDipilih;
    }
}
